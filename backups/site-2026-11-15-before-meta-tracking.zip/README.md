# Babyglee: landing page

Kids' sneakers sold on a three-step landing page, built for phones (visitors come from Facebook ads in Bangladesh). Everything is in English; prices are in taka (৳) with a US$ line.

| Step | File | What happens |
|---|---|---|
| 1 | `index.html` | Hero, five products (colour, photo gallery, sizes EU 21–36, add several to the cart), why sneakers for kids, why Babyglee, sole details, size finder, customer reviews, how ordering works, FAQ |
| 2 | `checkout.html` | Edit the cart, name, +88 mobile number, district, address, Cash on Delivery, place order |
| 3 | `thank-you.html` | Order confirmation; the `purchase` event fires here once |

Plus `shipping-returns.html`, `privacy.html`, `terms.html`.

## How it is built

- Pages are generated: edit `tools/build.py`, then run `python3 tools/build.py`. Do not hand-edit the generated `.html` files.
- `assets/main.js` (behaviour), `assets/style.css` (design), `assets/tracking.js` (GTM data layer, see `docs/gtm-tracking.md`).
- Backend: PHP 7.4+/8 + MySQL on cPanel hosting: `api/` (orders, live data, incomplete orders, optional Meta Conversions API) and `admin/` (orders, status, invoices, stickers, ads/UTM, stock, staff logins, reviews, photo gallery). Setup: `docs/backend-setup.md`.
- Without the backend (for example GitHub Pages) the site still works as a demo: orders are kept only in the visitor's browser and a demo notice is shown.

## Content you need to supply

- **Customer reviews:** Admin → Reviews (text or a screenshot of a real review). The section stays hidden until you add one. No reviews or statistics are made up.
- **More product photos:** Admin → Products → a product → *More photos*.
- Placeholders to confirm: price ৳1,290 (list ৳1,800), US$15, delivery ৳80 inside / ৳130 outside Dhaka, WhatsApp number (Admin → Settings).

## Rules

See `CLAUDE.md`: record every change below, back up before changing, mobile first, never commit `api/config.php`.

## Changelog

### 2026-11-15: New landing-page site (this repository)
- Rebuilt the earlier store site as a three-step landing page: choose products and sizes on page 1 (several products in one cart, sticky cart bar), checkout on page 2 (Cash on Delivery), thank-you on page 3.
- Page 1 content: hero with ৳ and US$ price, trust strip, product cards with photo gallery and size chips, size guide sheet, why sneakers for kids, why Babyglee, sole anatomy with hotspots, size finder, reviews section (hidden until reviews exist), 3-step ordering, FAQ.
- Backend adapted (schema v6): product photo gallery (`products.images`), reviews table and Admin → Reviews page (text or screenshot), `assets/reviews.js` served from the database, backup JSON includes reviews, products seeded with the landing-page URL.
- Tracking: `view_item_list`, `select_item`, `add_to_cart`, `view_cart`, `begin_checkout` (page 2), `purchase` on the thank-you page (once, with `event_id`, hashed customer data).
- Tested with Playwright: 32 checks in demo mode and 49 against the PHP backend (multi-product order, admin, reviews, gallery, stock, incomplete orders), no overflow at 1360/820/390/360px.
- Backup of the previous store site: `backups/babyglee-store-site-2026-11-15-source.zip`.
- Files: everything (new repository). Removed: store pages (shop, product, cart), the five separate ad pages, About/Contact pages.
