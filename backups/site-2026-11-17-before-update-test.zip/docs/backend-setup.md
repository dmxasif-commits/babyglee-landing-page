# Babyglee backend: cPanel setup guide

The backend is plain PHP + MySQL, so it runs on normal cPanel hosting (PHP 7.4 or newer, 8.x recommended).
It is part of the same folder as the website: upload everything together.

| Part | Path | What it does |
|---|---|---|
| Order API | `api/order.php` | Receives each order, re-checks it, calculates prices on the server, stores it |
| Live data | `api/live.php` | Gives the website its settings and products from the database |
| Admin panel | `admin/` | Orders, status, analytics, products, settings (GTM, delivery, Meta), backup |
| Product photos and review screenshots | `uploads/` | Images uploaded from the admin panel |

For connecting your hosting to GitHub so that merged changes go live by themselves (cPanel Git, cron, Cloudflare), see `docs/deploy.md`. The steps below are the manual version.

## 1. Install (about 10 minutes)

1. **Create the database.** cPanel → *MySQL Databases*: create a database, create a user with a strong password, add the user to the database with **All privileges**.
2. **Upload the site.** Upload all files of this repository to `public_html` (File Manager → Upload the zip → Extract, or Git Version Control).
   Make sure hidden files are uploaded too: `.htaccess` is required.
3. **Create the config file.** Copy `api/config.sample.php` to `api/config.php` and fill in the database name, user and password,
   and write a long random text as `setup_key`.
4. **Create the owner account.** Open `https://yourdomain.com/admin/`. Type the setup key, a username and a password (10+ characters).
   The tables and the five Bounce products are created automatically.
5. **Check it.** Open `https://yourdomain.com/assets/config.js`: it must start with `/* live from database */`.
   If you still see the static file, `.htaccess` was not uploaded or `mod_rewrite` is off (ask the host).
6. **Place a test order** on your phone, then find it in Admin → Orders.

Use **HTTPS** (cPanel → SSL/TLS Status → AutoSSL). The admin login cookie is only marked secure on HTTPS.

## 2. Daily use

- **Orders:** every new order is `Pending`. Call the customer, then set `Confirmed` → `Shipped` → `Delivered` (or `Cancelled` / `Returned`).
  Each change is saved in the order history with the time and your comment. Search by order ID, phone or name.
- **Reviews:** Admin → Reviews. Add a customer review as text or as a screenshot (for example from your Facebook page), choose stars, show or hide it.
  The Reviews section of the website stays hidden until at least one review is shown.
- **Dashboard:** orders and value per day, status, top products and sizes, traffic source (UTM), districts.
- **Products:** edit name, price, old price, USD price, colour, sizes in stock, image; hide or remove; add new products.
  A new product appears in the product grid on the landing page automatically.
  Use *More photos* (up to 6) to add extra pictures; the website shows them as thumbnails under the main photo.
- **Settings:** GTM container ID, delivery charges, WhatsApp number, Meta Conversions API, password.
  Website changes go live within about a minute.
- **Invoice and sticker:** open an order and use *Print invoice (A4)* or *Print sticker (3×4)*, or tick several orders in the list and choose a print action.
  For stickers, choose the 3 × 4 inch label as paper size in the print window, margins *None*, scale 100%.
- **Purchase price and profit:** enter your cost per pair on each product. Profit = product price minus purchase price (delivery charge and ad spend are not included).
  Orders placed before you entered a cost have no cost saved.
- **Ads (UTM):** shows which campaign, ad set and ad bring orders and how many of them get cancelled. It only works when your ads carry UTM tags.
  In Meta Ads Manager → ad → Tracking → URL parameters, paste:
  `utm_source=facebook&utm_medium=paid&utm_campaign={{campaign.name}}&utm_term={{adset.name}}&utm_content={{ad.name}}`
- **Courier:** save the courier name and tracking / consignment ID on the order; it prints on the invoice and sticker.
- **Sizes and stock:** on a product, each size is a row with its own stock. Tick *Count stock for this product* only after typing the real quantities:
  from then on a size with 0 pairs is sold out on the website. Cancelling or returning an order puts its pairs back.
- **Incomplete orders:** visitors who typed a valid mobile number but did not finish. Call them, then *Confirm and create order* (fill in address and size) or *Cancel*.
  Landing pages need a size before the order can be confirmed, so ask the customer on the call.
- **Staff logins:** Settings → Staff accounts. Give every person their own login. Staff see only orders and incomplete orders (no prices, profit, ads or settings).
  The order history shows who confirmed or cancelled each order, and the dashboard counts it per person. Switch an account off when someone leaves.
- **Manual orders:** Orders → *+ New order* for orders taken by phone or in a Facebook / WhatsApp / Instagram inbox.
- **Ad spend:** Ads → Campaign → *Ad spend*. Type what you spent per campaign (same name as the campaign in the table); you get cost per order, ROAS and net after ads.
- **Admin login:** the first admin account is created on the first visit to `/admin/` (type the setup key, a username and a password of 10+ characters). The username can be an email address (letters, numbers and `. _ - + @`, up to 40 characters; capital letters are ignored when logging in). Do not put the address or password in the repository or in `api/config.php`.
- **Server GTM Purchase:** Settings → *Server GTM backup for Purchase*. Paste the Measurement Protocol URL of your server container. The server then sends the Purchase of orders you confirm from Incomplete (or of every order, if you choose that) with the same ID as the browser event. See `docs/meta-tracking.md`.
- **Failed Purchase deliveries:** they are retried automatically (see `docs/meta-tracking.md`). Optional cron job: add `'cron_key'` to `api/config.php` (a long random text) and in cPanel → Cron Jobs run `curl -s "https://yourdomain.com/api/retry.php?key=YOUR_CRON_KEY" > /dev/null` every 5 minutes. Without cron, retries still run whenever an admin page is opened or an order arrives.
- **Backup:** Settings → *Download backup (JSON)*. Do it regularly (it contains customer details, keep it private).
  Also use cPanel → *Backup* for a full database backup.

## 3. Things to know

- **Prices are decided by the server.** The browser only sends product, size and quantity; a changed price in the browser is ignored.
- **Landing page:** the five Bounce products follow the price, sizes, photos and stock set in the admin. Customers can put several products in one cart.
- **Editing page text or layout** still happens in `tools/build.py` (then `python3 tools/build.py`). The admin controls data, not page design.
- **Meta Conversions API:** fill Pixel ID + access token in Settings to send `Purchase` from the server with the same event ID as the browser.
  Use *Test event code* first and check Events Manager → Test events. If a server-side GTM container already sends Purchase, leave these empty.
  The Graph API version is a setting because Meta retires old versions: check the current one in Meta's documentation.
- **Security built in:** hashed admin password, login attempt limit, CSRF protection on every form, HttpOnly session cookie,
  all database queries are prepared statements, uploads accept only real JPG/PNG/WebP images and cannot run scripts,
  private files are blocked by `.htaccess`, order flood limit (30 per hour per connection).
- **Never** commit or share `api/config.php`.

## 4. Free hosting for a demo

For showing the full site (store + orders + admin) to someone before buying hosting, a free PHP + MySQL host works, for example InfinityFree.
Follow the same install steps; the database host is not `localhost` there (the host shows it in its control panel), so set `host` in `api/config.php`.
Free hosts are slow, have daily limits and may block outgoing connections (Meta Conversions API), so use them for a demo only, never for real customers.

## 5. Local testing (developers)

```bash
BG_CONFIG=/path/to/test-config.php php -S 127.0.0.1:8770 router.php
```

`test-config.php` can use SQLite: `['db' => ['driver' => 'sqlite', 'path' => '/tmp/bg.sqlite'], 'setup_key' => '...']`.
The router must map `/assets/config.js`, `/assets/products.js` and `/assets/reviews.js` to `api/live.php` (what `.htaccess` does on Apache).
