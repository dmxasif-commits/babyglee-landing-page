# Babyglee: landing page

Kids' sneakers sold on a three-step landing page, built for phones (visitors come from Facebook ads in Bangladesh). Everything is in English; prices are in taka (৳) with a € international price line.

| Step | File | What happens |
|---|---|---|
| 1 | `index.html` | Hero, five products (colour, photo gallery, sizes EU 21–36, add several to the cart), why Babyglee® (benefits with the photo), size finder, customer reviews, how ordering works, FAQ |
| 2 | `checkout.html` | Edit the cart, name, +88 mobile number, district, address, Cash on Delivery, place order |
| 3 | `thank-you.html` | Order confirmation; the `purchase` event fires here once |

Plus `shipping-returns.html`, `privacy.html`, `terms.html`.

## How it is built

- Pages are generated: edit `tools/build.py`, then run `python3 tools/build.py`. Do not hand-edit the generated `.html` files.
- `assets/main.js` (behaviour), `assets/style.css` (design), `assets/tracking.js` (GTM data layer, see `docs/gtm-tracking.md`).
- Backend: PHP 7.4+/8 + MySQL on cPanel hosting: `api/` (orders, live data, incomplete orders, optional Meta Conversions API) and `admin/` (orders, status, invoices, stickers, ads/UTM, stock, staff logins, reviews, photo gallery). Setup: `docs/backend-setup.md`.
- Without the backend (for example GitHub Pages) the site still works as a demo: orders are kept only in the visitor's browser and a demo notice is shown.

## Content you need to supply

- **Customer reviews:** Admin → Reviews (text or a screenshot of a real review). The section stays hidden until you add one. No reviews or statistics are made up.
- **More product photos:** Admin → Products → a product → *More photos*.
- Placeholders to confirm: price ৳1,290 (list ৳1,800), €35, delivery ৳80 inside / ৳130 outside Dhaka, WhatsApp number (Admin → Settings).

## Rules

See `CLAUDE.md`: record every change below, back up before changing, mobile first, never commit `api/config.php`.

## Changelog

### 2026-11-19: Admin: Tracking audit page
- Backup of the live site before the change: `backups/site-2026-11-19-before-tracking-audit.zip`.
- New admin-only page **Tracking** (`?p=audit`). Period buttons as on the Dashboard (Today, Yesterday, 7/30/90 days, Custom). Summary: orders in the database, orders the dashboard counts (not cancelled / returned), cancelled / returned, orders that should have a browser Purchase in Meta, staff / recovered orders (no browser Purchase), server delivery state. A box "Purchases Meta shows for this period" + Compare explains the gap between Meta and the database. Table of every order: time, order, status, from (website / staff / recovered), total, event ID, Facebook ID present, server delivery, and warnings (cancelled / returned, same event ID, same phone twice in a day, no Facebook / visitor ID). Staff accounts cannot open it. Reads saved data only, no changes to orders or tracking.
- Files: `admin/index.php`, `admin/admin.css`, `docs/backend-setup.md`. Checked at 390 px with sandbox orders: no sideways scroll, ranges and compare work, no errors.

### 2026-11-19: 3D showcase moved into the hero (one section, not two)
- Backup of the live site before the change: `backups/site-2026-11-19-before-hero-showcase.zip`.
- The separate "Five colours, one happy fit" section is removed. The 3D podium showcase now sits **inside the hero**, in the place of the single-photo stage, between the headline and the ৳1,290 price box. Name of the front pair and the dots sit in one row under it. Swipe, arrows, dots, slow auto-turn and tap-to-shop work as before. The hero stays compact on phones (price and buttons still on the first screen at 360×740 and 390×844); on desktop the scene is taller.
- Files: `tools/build.py` (`showcase_block()` now returns the hero part; old `#stage` markup removed), `assets/style.css`, rebuilt pages. Checked at 360, 390 and 1280 px: no sideways scroll, no script errors.

### 2026-11-19: 3D shoe showcase under the hero
- Backup of the live site before the change: `backups/site-2026-11-19-before-showcase.zip`.
- New section **"Five colours, one happy fit"** right below the delivery strip: the five Bounce pairs stand on pastel podiums in front of arch shapes, built with CSS and a little JavaScript (not one picture). The front pair is large, the others turn away in 3D. Swipe, arrow buttons or dots change the pair; it also turns slowly by itself while on screen (off with reduced-motion). Tapping the front pair, or "Choose your pair", scrolls to the shop. Uses the existing shoe cut-out photos.
- Files: `tools/build.py` (`showcase_block()`), `assets/style.css`, `assets/main.js`, rebuilt pages. Checked at 360 and 390 px: no sideways scroll, no script errors.

### 2026-11-19: Dashboard and Ads: Today, Yesterday and a custom date range
- Backup of the live site before the changes: `backups/site-2026-11-19-before-date-ranges.zip`.
- **Period buttons** on the Dashboard and on the Ads & UTM report: **Today, Yesterday, 7 days, 30 days, 90 days, Custom** (before: only 7, 30, 90 days). **Custom** shows two date boxes (From, To) and a Show button; the dates can be entered in either order (they are swapped), never in the future, at most one year (a longer range is cut to 366 days), and invalid dates fall back to the last 7 days. A line under the buttons says what is shown ("Showing today (19 Nov).", "Showing 13 Nov – 19 Nov 2026 (7 days).").
- **One day = hourly chart:** for Today, Yesterday or a one-day custom range the Dashboard chart shows orders **per hour** (before: bars per day only); longer ranges still show bars per day (with no gaps between bars above 90 days).
- The Ads report keeps the chosen period when another tab (Campaign, Ad set, Ad, Placement, Device, Country …) is opened, and the ad-spend list on the Campaign tab follows the period too. The dashboard's "Today" card is now always today (before it depended on the chosen period), and the "Confirmed / Cancelled by staff" cards follow the period.
- Days start and end at midnight Bangladesh time (the server clock, `Asia/Dhaka`, that stamps the orders). Old links with `?days=7|30|90` keep working. Admin CSS is now linked with a content hash like the site's CSS (a changed `admin.css` reaches the browser at once). `admin/index.php` (`report_range()`, `range_picker()`), `admin/admin.css`.
- Tests (local backend, sandbox admin, orders spread over today, yesterday, five days ago and 40 days ago): Today = 2, Yesterday = 1, 7 / 30 days = 4, 90 days = 13, custom ranges (normal, reversed, end in the future, garbage, longer than a year, one day) on both pages; the hourly chart has 24 bars, the day charts 7 / 30 / 90 / 366 bars; dimension tabs keep the range; the buttons wrap on a 390 px phone; no page error. Not tested: the real database with real orders.
- Files: `admin/index.php`, `admin/admin.css`, `docs/backend-setup.md`, `README.md`.

### 2026-11-19: Ad details and visitor details kept with every order; Ads report by placement, device, country and more
- Backup of the live site before the changes: `backups/site-2026-11-19-before-ad-details.zip`.
- **From the ad link (new):** besides `utm_source`, `utm_medium`, `utm_campaign` (campaign), `utm_term` (ad set) and `utm_content` (ad) the site now keeps `utm_id` (campaign id), `adset_id`, `ad_id`, `placement` and `site_source` (fb, ig, msg, an). The ids stay the same when a name is changed, so two ads with the same name can be told apart. The one line to paste in Meta Ads Manager (ad → Tracking → URL parameters) is on Admin → Ads and in `docs/backend-setup.md`.
- **Worked out by the server (new, `api/lib.php`):** device (Mobile / Desktop / Tablet; crawlers show as Bot), system (Android 13, iOS 17, Windows …), browser (Chrome, Samsung Internet, Safari …, and the **Facebook app, Instagram app, Messenger app and TikTok app** in-app browsers), language, and **country** from Cloudflare's `CF-IPCountry` header, trusted only for requests that really come from Cloudflare addresses (empty without Cloudflare). Tested on typical user agents of Android and iPhone phones, an iPad, Windows and Mac, and the Meta crawler.
- **Kept against every order and every incomplete order** (inside the `tracking` data): `api/order.php` and `api/lead.php` use one list of fields (`BG_TRACKING_FIELDS`). The order's **Internal note** now starts with one readable line, for example `[Ad info] Source: facebook / paid · Campaign: Eid Sale · Ad set: Dhaka 25-40 Mothers · Ad: Video 1 · Placement: Facebook_Mobile_Feed (fb) · Device: Mobile, Android 13, Facebook app` (staff can edit the note; the figures stay in the tracking data). An order made from an incomplete order gets the line too.
- **Admin:** order page "Where it came from" shows all of it; the order list has one short line under each order; the CSV download has new columns (UTM medium, campaign / ad set / ad ids, placement, site source, device, system, browser, country). **Ads report** tabs: Campaign, Ad set, Ad / creative, **Campaign › ad set › ad**, **Placement**, Source, **Device**, **Country**, **System**, **Browser** (the ad spend table stays on the Campaign tab). Orders from before this change show device, system and browser (worked out from the stored browser) but no placement or country.
- **`assets/tracking.js`:** captures the new link fields, sends them with every event and order, and a visitor's ad details now **expire after 30 days** (before: never), so an old ad click is no longer credited to a later order.
- Tests (local backend with a sandbox admin): four orders from a Facebook-app Android phone, an Instagram-app iPhone and a Windows desktop with Meta-style links (names with `|`, spaces and Bangla text) and one without UTM: every field stored, note line written, order list line, order page rows, all ten report tabs, CSV columns; helper functions on 10 user agents and the Cloudflare country rule (header from a Cloudflare address is used, the same header sent directly is ignored). Not tested: real Cloudflare country values and real Meta macro values (the sandbox has neither).
- Files: `api/lib.php`, `api/order.php`, `api/lead.php`, `admin/index.php`, `assets/tracking.js`, `docs/backend-setup.md`, generated pages (new asset hash), `README.md`.

### 2026-11-18: Favicon from the Babyglee logo
- Backup of the live site before the changes: `backups/site-2026-11-18-before-favicon.zip`.
- The small icon in the browser tab / address bar was a generic teal square with the letter "b" drawn in code. It is now made from the **Babyglee logo** (`img/logo.webp`):
  - **Browser tab:** the "B" of the logo (its own teal and white lettering) on a white rounded plate, so it stays readable on light and dark tabs: `img/favicon.ico` (16, 32 and 48 px), `img/favicon-16.png`, `img/favicon-32.png`, `img/favicon-48.png`.
  - **Phone home screen / bookmarks:** the whole "Babyglee" lettering with the baby face on white: `img/apple-touch-icon.png` (180 px) and `img/icon-192.png` (192 px). The tab icon is only the "B" because the full logo is too small to read at 16–32 px.
  - The pictures were cut from the logo file with a small script (the pale bubbles and the slogan left out); the logo file is only 234 px wide, so no larger icon was made (it would be blurry).
- `tools/build.py`: `icon_links()` writes the four `<link>` tags into every page; the files are linked with the content hash (`?v=…`, see the cache fix below) because browsers keep favicons for a very long time. `.htaccess`: a request for `/favicon.ico` is answered with `img/favicon.ico` (some programs ask for that address directly).
- Tests (browser, all six pages): the four icon links load (200) with the right type and size (ICO; PNG 32×32, 16×16, 180×180), no failed request, no console error. Not tested: how each browser draws it, and `/favicon.ico` on the real server (the rewrite rule only works there). A browser may show the old icon for a while until its own favicon cache is renewed.
- Files: `tools/build.py`, `.htaccess`, `img/favicon*`, `img/apple-touch-icon.png`, `img/icon-192.png`, the six generated pages, `README.md`.

### 2026-11-18: New CSS/JS reach every visitor at once (cache fix)
- Backup of the live site before the changes: `backups/site-2026-11-18-before-cache-busting.zip`.
- **Problem found:** the previous update (phone layout, logo slider) was live on the server, but a phone that had visited before still showed the old look. The server sends `style.css` and the images with `cache-control: public, max-age=604800` (7 days), so a returning visitor kept the old CSS for up to a week while the page itself was already new.
- **Fix:** the pages now link `assets/style.css`, `assets/tracking.js` and `assets/main.js` with a short content hash (`?v=9663010b` and so on, computed from the file when `python3 tools/build.py` runs). A changed file gets a new link, so every browser fetches it at once; an unchanged file keeps its link and stays cached. `tools/build.py` (`asset()`), all generated pages.
- **Rule from now on:** after any change to `assets/style.css`, `assets/main.js` or `assets/tracking.js`, run `python3 tools/build.py` before committing (the hash is made then).
- Not covered: product photos that are replaced under the same file name (for example the Grey photo changed on 17 Nov) can stay cached for up to 7 days for returning visitors; a new file name avoids that.
- Tests (browser, 390 and 1280 px, home, checkout, thank-you, privacy): the stylesheet loads with its hash, the logo slider and the 430 px column are active, no failed request, no console error. Not tested: Cloudflare's own cache after the deploy.
- Files: `tools/build.py`, the six generated pages, `README.md`.

### 2026-11-18: Phone layout on every screen; the partner logos slide from left to right
- Backup of the live site before the changes: `backups/site-2026-11-18-before-phone-layout.zip`.
- **One layout, the phone layout, on every device.** There is no separate desktop design any more: on a desktop, laptop or tablet the site is shown as the same phone-sized column (430 px wide, centred, soft grey surround with a light shadow). On a phone nothing changes (checked: the home page, checkout and thank-you page at 360 and 390 px are pixel-identical to before apart from the logo strip and font anti-aliasing). Done in `assets/style.css`:
  - the rules for screens up to 980 px (the phone/tablet rules) now apply to every width (`@media all`); the rules for even smaller phones (≤ 380, ≤ 360, ≤ 315 px) and the height/landscape rules stay as real queries; the desktop-only rules (`min-width`) are removed (5-column grid, centred dialogs, static checkout button);
  - `body` is limited to `--col` (430 px) and centred; everything that is `position: fixed` follows the column instead of the whole window: the checkout bar, the floating WhatsApp and cart buttons, the menu panel, the shipping menu and the bottom sheets (cart, size guide, "Added to your cart").
- **"Our Official Partners" is now a slider:** one row of the four logos that moves slowly from left to right, endlessly (about 24 s per round), with soft fading edges. The logos are smaller (24–34 px high, each in its own proportions), not links and not clickable. The row is in the page twice so the loop has no gap (the second copy is hidden from screen readers); with "reduce motion" switched on the row stands still and shows the four logos once. HTML from `partners_block()` in `tools/build.py`.
- Tests (browser): widths 1920, 1280, 768, 430, 390, 360 all give a 430 px (or narrower) column, no horizontal scroll, burger menu, one product per row, no console errors; at 1280 px the menu panel, "Added to your cart" sheet, cart sheet, checkout bar and floating buttons all sit inside the column; the logo row moves to the right; checkout, thank-you and the three policy pages are single-column at 1280 px. Not tested: real phones, real hosting.
- Files: `assets/style.css`, `tools/build.py`, generated pages, `README.md`.

### 2026-11-18: Delivery "1–3 days"; "Our Official Partners" logo strip under the reviews
- Backup of the live site before the changes: `backups/site-2026-11-18-before-partners-delivery.zip`.
- **Delivery timeframe is now "1–3 days"** everywhere (it comes from one constant, `DELIVERY` in `tools/build.py`): delivery line under the hero, order steps, FAQ, Shipping & Returns, thank-you page and the "Added to your cart" pop-up. Still no "working days".
- **"Our Official Partners" section** directly below the reviews section ("What parents say"): a short heading and four logos (ToguMogu, Shishu Poribohon, Prelegant Mall, Rokomari) supplied by the owner. The logos are not links and cannot be clicked (no `<a>`, pointer events off, not draggable) and are shown in their own proportions (checked: displayed ratio = natural ratio for all four). Two columns on phones, four on larger screens. The section is separate from the reviews, so it shows even while the reviews section is hidden.
- **Logo files** (`img/partners/togumogu.webp`, `shishu-poribohon.webp`, `prelegant-mall.webp`, `rokomari.webp`): the supplied pictures with their flat background removed (transparent) and cropped to the logo, at most 480 px wide (5–28 KB each). The section is built only from the files that exist in `img/partners/`, so a logo can be changed by replacing its file.
- Tests (browser, 360, 390 and 1280 px, with and without reviews): heading text, the section sits right after `#reviews`, 0 links, all four images loaded with unchanged aspect ratios, no horizontal scroll, no console errors.
- Files: `tools/build.py`, `assets/style.css`, `img/partners/*.webp`, generated pages, `README.md`.

### 2026-11-18: Thank-you page: customer data in the dataLayer before GTM starts; no GTM on developer hosts
- Backup of the live site before the changes: `backups/site-2026-11-18-before-prestart-data.zip`.
- **Why:** the Meta Pixel is started by the GTM container; on the thank-you page the hashed customer data only appeared in the later `purchase` push, so the Pixel began without it (the browser Purchase showed no email, phone, name or city, while the server events had them).
- **`assets/tracking.js`:** on `thank-you.html`, `{ external_id, meta_user_data }` is pushed as the very first `dataLayer` entry, before the `gtm.js` entry, from the order in `sessionStorage` (`bg_last_order`); the GTM loader now runs after it (it moved below the helpers, nothing else changed). Hashing there is synchronous (the existing pure-JS SHA-256) and uses the same normalisation as the purchase push (shared `metaNorm()`), so both entries hold identical values (tested: equal to Node's SHA-256 for `em`, `ph`, `fn`, `ln`, `ct`, `country`, `external_id`). No order (new tab, nothing placed) or a demo order: no entry. The `event_id` is not in this first entry on purpose (the PageView would otherwise read the purchase ID); it stays in the single `purchase` push, which is unchanged (key names, `event_id` = `purchase_<orderId>`, `ecommerce.transaction_id`, `ecommerce.shipping`, items, `meta_user_data`) and is still sent once per order (sessionStorage and localStorage guard).
- **Hashes (unchanged, confirmed):** SHA-256 lowercase hex; `em` lowercase and trimmed; `ph` digits with country code, no plus (`8801XXXXXXXXX`); `fn`, `ln`, `ct` lowercase without punctuation or spaces; `country` = hash of `bd`. `external_id`: the plain visitor UUID (cookie `bg_uid`) is the top-level `external_id` on every event (including the new first entry); `meta_user_data.external_id` is the SHA-256 of exactly that UUID.
- **No GTM on developer or preview hosts:** `localhost`, `127.x`, `*.local` and `*.github.io` do not load the container (so testing there cannot reach the live Pixel, dataset 928926128808306, or GA4); `?bggtm=1` starts it on purpose for the tab. The site sends no `test_event_code` from the browser (only the optional server-side Conversions API setting in Admin → Settings has one, and it is empty).
- Tests (local backend, real order path, GTM requests answered with an empty script): console snippet on the thank-you page → index 0 `meta_user_data`, index 1 `gtm.js`, index 2 `page_data`, one `purchase`; seed equals the purchase `meta_user_data`; reload sends no second `purchase`; new tab without an order has no entry; home and checkout pages unchanged; full-flow regression (purchase counts, external_id on all events). Not tested: the live Pixel and CAPI.
- Files: `assets/tracking.js`, `docs/gtm-tracking.md`, `README.md`.

### 2026-11-17: International price €35, bKash info only, new product names, new Grey photo
- Backup of the live site before the changes: `backups/site-2026-11-17-before-euro-grey-update.zip`.
- **International price is now €35** (hero line and product cards show "€35"). The database field (`price_usd`) and the JSON key (`priceUsd`) keep their old names to avoid breaking anything; the admin label reads "International price (€)". Schema v9 sets it to 35 only for products still at an old default (15 or 30); a price you set yourself is kept.
- **Payment: bKash is information only, no card.** Where the site mentioned card payment (FAQ, order steps, checkout, Shipping & Returns, Terms) the card wording is removed. bKash merchant account 01974974973 (Payment option) is shown as information; the order itself is still recorded as Cash on Delivery.
- **Product names from the backend code:** schema v9 renames the five products by slug (`bounce-sky-blue`, `bounce-blue-beige`, `bounce-grey`, `bounce-navy-brown`, `bounce-black`) to "Sneaker – Multi Color", "Sneaker – Blue & Beige", "Sneaker – Charcoal Grey", "Sneaker – Dark Navy", "Sneaker – Black" (colour names without the prefix). Slugs, SKUs and photos stay, so GA4/Meta item IDs do not change. The migration runs once, on the first request after the deploy; names edited later in Admin → Products are kept. The fresh-install seed and the static fallback use the same names.
- **New photo for the Grey product (`img/grey.webp`):** the supplied photo with the grey studio background and floor shadows removed (transparent, like the other four photos, so the card colour shows through), cropped and resized to 900 px wide (60 KB).
- **Customer reviews from the main website (given by the owner):** the ten testimonials on babygleebd.com/welcome/Bangladesh (the Facebook page reviews) are added by schema v10, name and text exactly as published. A text cut off by the main site ("quali...") is shortened to its last full sentence and nothing is added or changed. No photos (they show private people and children) and **no star rating**: the main site publishes none, so rating 0 is stored; `assets/main.js` now shows no stars for a review without a rating and counts only rated reviews in the average (the summary reads "10 reviews from our customers"). Added only when the reviews table is empty, so reviews added in Admin are never duplicated; edit, hide or delete them in Admin → Reviews.
- Partner logos: not added. They are not on the main babygleebd.com pages (checked `/`, `/shop`, `/shop/bangladesh`, `/welcome/Bangladesh`); the section appears as soon as the four logo files are placed in `img/partners/`.
- Tests: schema migration on a copy of an old database (names and colours renamed, 30 → 35, a custom price 40 kept, fresh install seeds the new names; reviews: seeded once when none exist, not when the owner already has one, schema_version 10) and a browser check at 360, 390 and 1280 px (title, "€35" in the hero and on the card, the reviews section with 10 cards and no stars, no horizontal scroll, no console errors).
- Files: `tools/build.py` (generated pages and `assets/products.js`), `api/lib.php`, `admin/index.php`, `assets/main.js`, `assets/config.js`, `img/grey.webp`, `docs/backend-setup.md`, `README.md`.

### 2026-11-17: Tracking tidy-up (dataLayer only, no key renames)
- Backup of the live site before the changes: `backups/site-2026-11-17-before-datalayer-update.zip`.
- **`external_id`:** the visitor UUID lives in the first-party cookie `bg_uid`, renewed on every visit (asked for 730 days; Chrome caps script-set cookies at 400 days, Safari is shorter). A copy in localStorage restores the cookie when it expires or is cleared, so the value stays the same on every page and visit.
- **Purchase once per order:** the order id is stored in sessionStorage and localStorage (`bg_purchased`, last 50 orders) and is checked again in the same moment the event is pushed, so a reload, back/forward or a later visit to the thank-you page sends nothing. The event_id stays `purchase_<orderId>`.
- Checked, no change needed: `meta_user_data` on `purchase` already holds SHA-256 hashes of the phone (digits with country code, `8801700000000`), first name, last name, city, country and external_id (first name and city are lowercased and stripped of punctuation and spaces, as Meta specifies). Every other event's `event_id` is unique per event (tested over a browsing session).
- Not possible as asked: `begin_checkout` fires when the checkout page opens, before the visitor has typed anything, so it has no name, phone or city to hash. The first events that carry `meta_user_data` are `add_shipping_info`, `add_payment_info`, `generate_lead` and `purchase`.
- Decided by the owner: `ecommerce.value` stays the product price without delivery (1290); delivery stays in `ecommerce.shipping` (`order_total` is sent next to it).
- Files: `assets/tracking.js`, `assets/main.js`, `docs/gtm-tracking.md`, `docs/meta-tracking.md`, `README.md`.

### 2026-11-17: Copy update from the team's "Landing page" review document
- Backup of the live site before the changes: `backups/site-2026-11-17-before-copy-update.zip`.
- **Announcement bar:** "Available in Bangladesh · Designed for European markets · Cash on Delivery · 72-Hour Easy Exchanges" plus a tap-to-call number; on phones it shows "Available in Bangladesh" and the number. Nav: Why Babyglee®, Size Guide, Shop Now.
- **Hero:** new headline and text ("Designed for active, healthy feet development."), the "International brand" pill is gone, "(Cash on Delivery)" next to the price, chip "Soft cushioning". The four trust badges under the hero are removed; only the delivery line stays.
- **Delivery everywhere is now "2–3 days"** (no "working days"): delivery line, order steps, FAQ, Shipping & Returns, thank-you page, cart pop-up.
- **Products:** section text "Choose your size, fill your cart, and check out all at once."; seed/fallback names are now Multi Color, Blue & Beige, Charcoal Grey, Dark Navy, Black. The live names come from Admin → Products and must be renamed there.
- **"Why Babyglee®" and "The details that matter" are one section:** new headline and text, the sneaker photo with numbered points next to six benefits (Breathable Microfiber, Soft & Comfortable Cushioning, Easy Front-Lock Strap, Anti-Slip Rubber Sole, Zero Toxic Chemicals, European Design).
- **Size guide:** the insole length is shown in cm and inches (table and the size finder note).
- **Order steps** reworded ("Three-Step Order Process"); a line with the payment options (Cash on Delivery, bKash merchant 01974974973, card via WhatsApp). The checkout shows the same options as information; the order itself is still recorded as Cash on Delivery.
- **FAQ** ("Got Questions? We've Got Answers.") and the **Shipping & Returns, Privacy and Terms** pages use the content of the main babygleebd.com pages, adapted to this site where the main store text does not apply (no customer accounts, Bangladesh delivery in 2–3 days, 72-hour exchange, payment options, size advice = insole = foot + 1 cm).
- **Footer:** "Ready for Healthy Growing Feet?", new blurb ("available in Bangladesh"), columns Customer Care / Shop / Company / Reach Us, office hours 11 AM – 9 PM (BST).
- **New: "Added to your cart" pop-up** after every add to cart (product, size, cart total, Continue shopping / Checkout).
- **New: partner logos section** (ToguMogu, Shishu Poribohon, Prelegant Mall, Rokomari). It appears only for logo files placed in `img/partners/` (`togumogu`, `shishu-poribohon`, `prelegant-mall`, `rokomari`, as `.svg`, `.webp`, `.png` or `.jpg`); no logos are invented.
- Fixed: the `size_guide_open` event was swallowed by a comment in `assets/main.js` and never fired.
- Not done (needs the owner): customer reviews from Facebook (add real reviews in Admin → Reviews; none are copied or invented), the international price "35 Euro" (the site still shows US$30, see the open questions), a bKash/card payment choice that is saved on the order.
- Files: `tools/build.py`, `assets/main.js`, `assets/style.css`, generated pages and `assets/products.js`, `README.md`.

### 2026-11-17: Update on request when the hosting does not allow exec()
- The real hosting (LiteSpeed) switches PHP's `exec()` off, so the webhook answered 501 and could not start the update. `api/deploy.php` now writes a request file (`~/.babyglee-update-requested`) after a signed push to `main` and answers `{"ok":true,"queued":true}`; where `exec()` works it also starts the update at once (`started`).
- `tools/auto-update.sh --on-request` (cron job, every minute): stops immediately unless the request file exists (no GitHub contact otherwise), claims the file atomically, deploys, removes it; a failed attempt is kept and retried for up to 60 minutes (then dropped and logged); paused updates keep the file; a webhook arriving mid-update is not lost. Without the argument the script behaves as before.
- `docs/deploy.md` section 4 rewritten around this flow.
- Tests: 44 sandbox checks (the earlier 29 + 15 new: no flag = nothing, no GitHub contact, flag = update and removal, nothing new, paused, retry after failure, give-up after an hour, webhook with `exec` disabled leaves the file and deploys nothing itself, other branch and wrong signature leave no file) + deploy and IP suites. Not tested: a real cPanel cron job.
- Backup before this change: `backups/site-2026-11-17-before-flag-update.zip`.
- Files: `api/deploy.php`, `tools/auto-update.sh`, `docs/deploy.md`.

### 2026-11-17: Test of the automatic update (GitHub webhook)
- New harmless file `assets/version.txt`. After this is merged, it should appear at `/assets/version.txt` on the live site within seconds without any click in cPanel; that proves the webhook, `api/deploy.php`, `tools/auto-update.sh` and `tools/deploy.sh` work together on the real hosting. Nothing else changed.
- Backup before this change: `backups/site-2026-11-17-before-update-test.zip`.
- Files: `assets/version.txt`.

### 2026-11-16: Webhook is the recommended way to update (no per-minute cron)
- `docs/deploy.md` section 4 reordered: **A** the GitHub webhook (the server updates only when `main` changes, i.e. when you say "merge"; includes how to check Recent Deliveries and what 403 / 501 mean), **B** two clicks in cPanel Git Version Control, with an optional cron every 30–60 minutes as a safety net instead of every minute, and how to hold updates with `~/.babyglee-paused`. No code changed (`api/deploy.php` and `tools/auto-update.sh` were added earlier).
- Backup before this change: `backups/site-2026-11-16-before-webhook-docs.zip`.
- Files: `docs/deploy.md`.

### 2026-11-16: US$30, delivery time line, floating cart above WhatsApp
- International price is now **US$30** (hero, product cards, product data). Schema v8 updates existing products whose US price is still the old default 15 to 30; a price you changed yourself in Admin is kept.
- New full-width line under the four trust items on the home page: "Order today, delivered in **3–5 working days** across Bangladesh". FAQ ("How does delivery work?", "Where do you deliver?") and the Shipping & returns page now say 3–5 working days too.
- Cart on phones: the bottom bar is now only the wide **Checkout · ৳…** button; the cart button is the floating round icon above the WhatsApp button (and the bag in the header). Both floating buttons hide while the hero buttons are on screen, and are smaller on short phones. The checkout page still sends `view_cart` + `begin_checkout` for every visitor who reaches it; opening the cart sheet sends one more `view_cart`.
- Tests: 55 new (delivery line at 6 widths, US$30, button order and overlap, view_cart) + all earlier browser suites (35 + 12 + 43 + 65 + 31) + 34 and 52 backend + v7 to v8 migration check.
- Backup before this change: `backups/site-2026-11-16-before-price-delivery-cart.zip` (made without the `backups/` folder).
- Files: `tools/build.py`, `assets/main.js`, `assets/style.css`, `api/lib.php`, generated pages.

### 2026-11-16: Auto-update from GitHub, instant webhook, backups, rollback
- `tools/auto-update.sh` (cron, every minute): pulls `main` and deploys only when there is a newer commit; skips while paused or while another update runs; logs to `~/deploy.log`; a failed deploy is logged and retried on the next run.
- `api/deploy.php` (optional GitHub webhook, a few seconds): needs `deploy_secret` in `api/config.php`, verifies GitHub's HMAC-SHA256 signature, reacts only to a push to `main`, runs only the fixed update script after answering; 404 without a secret, 401 for a wrong or missing signature, 501 when `exec()` is off.
- `tools/deploy.sh`: one deploy at a time (lock), a backup of the live files before every deploy over an existing site (`~/deploy-backups`, newest 10, private), records the deployed commit; no duplicate cPanel PHP block when the new `.htaccess` already has it.
- `tools/rollback.sh`: restores the previous (or a named) backup, backs up the current files first, pauses automatic updates (`~/.babyglee-paused`).
- `docs/deploy.md` section 4 rewritten: chat → PR → "merge" → live; cron, webhook, backups and rollback.
- Tests: 29 checks in a sandbox with a fake GitHub (deploy, no-op run, backup contents and permissions, retention, rollback, pause and resume, two updates at once, failed deploy retried, signed webhook accepted, wrong, missing and mismatched signatures refused, other branch ignored, ping, GET, no secret) + 36 deploy + 11 IP checks. Not tested: a real cPanel account, GitHub webhook delivery, Cloudflare.
- Backup before this change: `backups/site-2026-11-16-before-auto-deploy.zip`. This and all later backups are made without the `backups/` folder (`git archive --format=zip -o backups/<name>.zip origin/main -- . ':(exclude)backups'`): before, each backup contained every earlier one and doubled in size, and the last one (142 MB) hit GitHub's 100 MB file limit. The older zips in the repository add up to about 140 MB and make the first clone slow; they can be moved out of the repository when you decide.
- Files: `tools/auto-update.sh` (new), `tools/rollback.sh` (new), `tools/deploy.sh`, `api/deploy.php` (new), `api/config.sample.php`, `docs/deploy.md`.

### 2026-11-16: Deploy keeps the cPanel PHP version block
- `tools/deploy.sh` no longer overwrites the cPanel-generated PHP handler block (`# php -- BEGIN/END cPanel-generated handler`, which holds "PHP 8.2 / ea-php82") when it replaces the web folder's `.htaccess`: the block is read first and appended to the new file (once, also after repeated deploys). Before, a deploy could drop the domain's PHP version setting.
- The first deploy also keeps a copy of the existing `.htaccess` (for example cPanel's Force HTTPS rule) as `.htaccess.before-deploy`; it is created once and never overwritten.
- `docs/deploy.md`: when the site is the account's main domain the Document Root is usually `public_html`; check the folder exists and save the path file; Cloudflare must be on Full / Full (strict) when cPanel's Force HTTPS Redirect is on.
- Tests: deploy simulation now has an existing cPanel handler block (36 checks: original .htaccess saved once, block kept once, site rules present, nothing duplicated on a second deploy, rsync and copy fallback).
- Backup before this change: `backups/site-2026-11-16-before-htaccess-preserve.zip`.
- Files: `tools/deploy.sh`, `docs/deploy.md`.

### 2026-11-16: Hosting deploy from GitHub, real visitor IP behind Cloudflare
- New `docs/deploy.md`: Cloudflare DNS/SSL, cPanel PHP and database, cPanel Git Version Control, auto-update by cron (merged changes go live within about 5 minutes), first-run checks.
- New `tools/deploy.sh` and `.cpanel.yml`: copy only the website files (pages, `assets/`, `img/`, `admin/`, `api/`, `.htaccess`) into the web folder named in `~/.babyglee-deploy-path`; `api/config.php` and everything in `uploads/` are never touched; tools, docs, README and backups are not published; it refuses the home folder, `/` and missing folders; rsync removes files deleted from the repository, with a plain-copy fallback when rsync is missing.
- Fix for sites behind Cloudflare: `client_ip()` now uses `CF-Connecting-IP`, but only when the request comes from a Cloudflare address. Before, every visitor looked like one of a few Cloudflare addresses, which would trip the per-address order and incomplete-order limits and send wrong IPs to Meta and server GTM.
- Tests: 26 deploy checks in a simulated cPanel account (rsync and fallback, protected files, refusals, repeat run) and 11 client-IP checks (IPv4/IPv6, range edges, spoofed header); live-backend suites still pass. Not tested: a real cPanel account, cPanel Git Version Control, Cloudflare.
- Backup before this change: `backups/site-2026-11-16-before-deploy-setup.zip`.
- Files: `tools/deploy.sh`, `.cpanel.yml`, `api/lib.php`, `docs/deploy.md`, `docs/backend-setup.md`.

### 2026-11-16: Delivery retries, Meta fields, user agent (second tracking review)
- Fixed my own regression: an inline comment had cut `order_id` and `content_type` (and the rest of that line) out of the Meta Conversions API `custom_data`. A test now checks them.
- Server GTM request: Meta-ready matching fields sent separately from the Google ones (`meta_ph` is the phone as digits `880...` without `+`, plus `meta_em`, `meta_fn`, `meta_ln`, `meta_ct`, `meta_country`, `meta_external_id`); `ip_override` is also at the top level of the request; the request's User-Agent header is the customer's.
- Incomplete orders now keep the customer's user agent (`leads.user_agent`), carried into the order created from Admin → Incomplete.
- Durable delivery: `api/dispatch.php` (moved out of `capi.php`) keeps a status per destination, retries failures after 1, 5, 15, 60 and 240 minutes (six tries), never resends what already succeeded, and runs after the order answer is sent (customers never wait for it). Retries run when an admin page opens, when an order arrives, and from the optional cron endpoint `api/retry.php?key=...` (`cron_key` in `api/config.php`). Order page: status and "Try again now"; dashboard warns about failed deliveries. Schema v7 (`orders.dispatch*`, `leads.user_agent`); a v6 database upgrades in place.
- Page leave: if `sendBeacon()` refuses the save (returns false) a keepalive request is sent instead.
- Checkout waits at most 1.2 s for tracking (both steps run together), not two 2 s waits in a row.
- Tests: 31 browser checks, 34 backend checks (mock Meta and server GTM that can fail or stall), v6 to v7 upgrade, plus 35 demo + 52 backend + 12 dataLayer + 43 size + 65 small-screen pass. Not tested: a real server GTM container, Meta delivery, real EMQ.
- Backup before this change: `backups/site-2026-11-16-before-delivery-retries.zip`.
- Files: `api/dispatch.php` (new), `api/retry.php` (new), `api/capi.php`, `api/order.php`, `api/lead.php`, `api/lib.php`, `api/config.sample.php`, `.htaccess`, `admin/index.php`, `assets/main.js`, `docs/`.

### 2026-11-16: Tracking reliability (from the tracking review)
- Incomplete orders: a save counts as done only after the backend answers ok; network errors and 5xx/408/429 are retried (2, 5, 15, 40 s); the page-leave save uses `sendBeacon`; the `generate_lead` event is sent after the first confirmed save.
- `view_item_list` now fires when the first product card shows (it could never fire on a 320x568 phone before).
- `_fbc` is replaced when a new ad click (different `fbclid`) arrives; case and format are kept. `page_data` now carries a shared `event_id` for PageView de-duplication; `whatsapp_click` has an `event_id` and identifiers.
- Purchase: built from the accepted order (items, prices, shipping, total returned by `api/order.php`); marked as reported only after it is pushed; demo orders send no Purchase (`localStorage.bg_track_demo = '1'` to test); checkout never waits more than 2 s for tracking.
- Server-side Purchase delivery: `dispatch_purchase()` for web orders and for orders confirmed from Admin → Incomplete (previously none). Optional server GTM Measurement Protocol URL and mode (recovered / every order / never) in Admin → Settings; Meta value is now the product value, as in the browser event; the order stores the visitor ID (`uid`) and GA client cookie.
- Cart: "+" inside the cart sends `add_to_cart`; adding beyond 10 pairs of a size reports only the pairs added (none at the limit, with a message); the shipping step also fires when the name is the last field completed.
- Admin: the username can be an email address.
- Docs: `docs/meta-tracking.md` (trigger/tag mapping, external ID, Lead meaning, Purchase reliability) and `docs/backend-setup.md`.
- Tests: 28 new browser checks, 18 new backend checks (mock Meta and server GTM receivers) + 35 demo + 52 backend + 12 dataLayer + 43 size + 65 small-screen pass. Not tested: a real GTM container, Meta delivery, real EMQ.
- Backup before this change: `backups/site-2026-11-16-before-tracking-reliability.zip`.
- Files: `assets/main.js`, `assets/tracking.js`, `api/capi.php`, `api/order.php`, `api/lead.php`, `api/lib.php`, `admin/index.php`, `docs/`.

### 2026-11-15: Small screens, short screens and landscape
- Hero: the background circle no longer covers the heading, price or note (it is sized to the picture area); on short and landscape screens the layout is tighter (landscape phones use two columns). The WhatsApp button hides while the hero buttons are on screen and returns when you scroll.
- Checkout at 320px (and down to 300px): the form and the expanded "Order summary" no longer widen the page (grid columns and inputs can shrink; summary lines stack on very small phones).
- Header at 320px and below: logo, country button, bag and menu all fit; the bag and menu buttons keep their full size (below 315px only the flag and arrow show for the country).
- Size popup: reopening it keeps the typed measurement and shows "Select EU xx" again.
- Size guide: nothing is suggested outside the chart. A foot over 21 cm (insole over 22 cm), a wide-foot choice at EU 36, or a foot under 12 cm shows "No matching size" with a message to contact us, and no Select button.
- Tests: 65 new small-screen checks (10 screen sizes, checkout at 8 widths, popup and limits) + 43 size + 35 demo + 52 backend + 12 dataLayer pass.
- Backup before this change: `backups/site-2026-11-15-before-small-screen-fixes.zip`.
- Files: `assets/main.js`, `assets/style.css`.

### 2026-11-15: Size finder, menu, hero and checkout bar
- Size recommendations now follow the live product guide: insole length = foot length + 1 cm (a 15 cm foot gives EU 26). The size table shows foot length, insole length and age for EU 21–36 from that chart; a "wide feet or thick socks" option moves one size up.
- Size guide is now a full-width "Find the right size" button on every product card, above the EU sizes. The sheet has 3 measuring steps, a centimetre field, the suggested size and "Select EU xx". The same finder is in the Size guide section.
- Mobile menu fixed: the panel is now full height (the header blur made the fixed panel only as tall as the header); a dark backdrop shows, and tapping outside closes it.
- Hero is compact on phones: headline, shoes, price and the two buttons fit the first screen (also at 360x640); the intro paragraph and badge are hidden there.
- Persistent bottom bar "Checkout · ৳1,290" (total follows the cart) with a small cart button for the cart sheet; it replaces the floating bag icon. WhatsApp stays on the right above it.
- Tests: 43 new (size logic against every chart row, hero, menu, bar) + 35 demo + 52 backend + 12 dataLayer pass.
- Backup before this change: `backups/site-2026-11-15-before-size-menu-hero.zip`.
- Files: `tools/build.py`, `assets/main.js`, `assets/style.css`, regenerated `index.html`.

### 2026-11-15: Complete dataLayer for GTM / Meta (server-side GTM)
- Every e-commerce event now carries `event_id`, `event_time`, `event_source_url`, `external_id`, `fbp`, `fbc`, UTMs/click IDs and a ready-made `meta_custom_data` (content_ids = SKUs, contents, num_items, value, BDT).
- New `generate_lead` event (incomplete order) when a valid mobile number is typed in checkout; carries the hashed customer data and cart. Works with or without the backend.
- `_fbp` is created by the site when the Pixel has not made it yet; `_fbc` keeps its case.
- Admin → Settings: the Meta Conversions API box now says to leave it empty when server-side GTM sends the events.
- New `docs/meta-tracking.md` (events, fields, what the server container adds, EMQ checklist, how to test); `docs/gtm-tracking.md` updated.
- Tests: 12 new dataLayer checks (hashing, identifiers, custom_data, lead, purchase) + the earlier 32 + 49 pass.
- Backup before this change: `backups/site-2026-11-15-before-meta-tracking.zip`.
- Files: `assets/tracking.js`, `assets/main.js`, `admin/index.php`, `docs/`.

### 2026-11-15: Mobile polish (flag, floating cart, receipt, footer)
- Bangladesh flag icon replaces the "BD" badge (header country button, country menu, phone and country fields).
- WhatsApp button moved to the right; a floating cart button sits above it (shown when the cart has items). Tapping it, or the bag in the header, opens a cart sheet with names, sizes, quantities, edit/remove, total and Checkout. The old bottom cart bar is removed.
- Thank-you page redesigned for phones: stacked receipt (items with quantity on the right, delivery address, amount to pay).
- Footer made shorter on phones: brand row, two-column links, two-column contact details.
- Backup before this change: `backups/site-2026-11-15-before-mobile-polish.zip`.
- Files: `tools/build.py`, `assets/main.js`, `assets/style.css`, regenerated `.html`. Tests: 32 (demo) + 49 (backend) pass.

### 2026-11-15: New landing-page site (this repository)
- Rebuilt the earlier store site as a three-step landing page: choose products and sizes on page 1 (several products in one cart, sticky cart bar), checkout on page 2 (Cash on Delivery), thank-you on page 3.
- Page 1 content: hero with ৳ and US$ price, trust strip, product cards with photo gallery and size chips, size guide sheet, why sneakers for kids, why Babyglee, sole anatomy with hotspots, size finder, reviews section (hidden until reviews exist), 3-step ordering, FAQ.
- Backend adapted (schema v6): product photo gallery (`products.images`), reviews table and Admin → Reviews page (text or screenshot), `assets/reviews.js` served from the database, backup JSON includes reviews, products seeded with the landing-page URL.
- Tracking: `view_item_list`, `select_item`, `add_to_cart`, `view_cart`, `begin_checkout` (page 2), `purchase` on the thank-you page (once, with `event_id`, hashed customer data).
- Tested with Playwright: 32 checks in demo mode and 49 against the PHP backend (multi-product order, admin, reviews, gallery, stock, incomplete orders), no overflow at 1360/820/390/360px.
- Backup of the previous store site: `backups/babyglee-store-site-2026-11-15-source.zip`.
- Files: everything (new repository). Removed: store pages (shop, product, cart), the five separate ad pages, About/Contact pages.
